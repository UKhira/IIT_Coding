/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.tutorial01messagepassing;

/**
 *
 * @author Hamed
 */
// Receiver class to receive and process a message
public class Receiver {
    public void receiveMessage(Message message) {
        System.out.println("Message received: " + message.getContent());
    }
}